package com.example.personalconsole;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(17, 19, 21);
    private final int panel = Color.rgb(27, 30, 32);
    private final int edge = Color.rgb(49, 53, 56);
    private final int primary = Color.rgb(239, 242, 242);
    private final int muted = Color.rgb(157, 165, 170);
    private final int accent = Color.rgb(190, 216, 205);

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        getWindow().getDecorView().setSystemUiVisibility(0);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(28), dp(22), dp(28));
        root.setBackgroundColor(bg);
        scroll.addView(root);

        TextView eyebrow = text("PERSONAL / SPACE", 12, muted, false);
        eyebrow.setLetterSpacing(0.18f);
        root.addView(eyebrow);

        TextView title = text("个人控制台", 32, primary, true);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(-1, -2);
        titleLp.topMargin = dp(10);
        root.addView(title, titleLp);

        TextView subtitle = text("安静、有序，把常用的放在手边。", 15, muted, false);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(-1, -2);
        subLp.topMargin = dp(8);
        root.addView(subtitle, subLp);

        section(root, "设备概况", "本应用可读取的信息");
        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(row1);
        row1.addView(card("运行环境", "原生 Android", "应用本身运行状态", 1));
        row1.addView(card("数据策略", "不伪造", "未获权限的数据会明确说明", 1));

        section(root, "快捷设置", "打开系统设置页面");
        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(row2);
        row2.addView(actionCard("网络设置", "连接与网络", new Runnable() {
            public void run() { launch(Settings.ACTION_WIRELESS_SETTINGS); }
        }));
        row2.addView(actionCard("显示设置", "亮度与显示", new Runnable() {
            public void run() { launch(Settings.ACTION_DISPLAY_SETTINGS); }
        }));

        LinearLayout row3 = new LinearLayout(this);
        row3.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams row3lp = new LinearLayout.LayoutParams(-1, -2);
        row3lp.topMargin = dp(10);
        root.addView(row3, row3lp);
        row3.addView(actionCard("应用设置", "权限与应用", new Runnable() {
            public void run() { launch(Settings.ACTION_APPLICATION_SETTINGS); }
        }));
        row3.addView(actionCard("声音设置", "音量与铃声", new Runnable() {
            public void run() { launch(Settings.ACTION_SOUND_SETTINGS); }
        }));

        section(root, "说明", "透明、可控");
        TextView note = text("这是第一个原生版本。当前仅提供系统设置入口与静态说明；电量、步数、消息读取、设备控制等功能尚未接入，不会显示虚构数据。", 14, muted, false);
        note.setPadding(dp(16), dp(16), dp(16), dp(16));
        note.setBackground(round(panel, dp(16), edge));
        root.addView(note);

        TextView footer = text("PERSONAL CONSOLE  ·  VERSION 1.0", 10, muted, false);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams footLp = new LinearLayout.LayoutParams(-1, -2);
        footLp.topMargin = dp(24);
        root.addView(footer, footLp);

        setContentView(scroll);
    }

    private void section(LinearLayout root, String name, String hint) {
        LinearLayout line = new LinearLayout(this);
        line.setGravity(Gravity.CENTER_VERTICAL);
        line.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(28);
        lp.bottomMargin = dp(12);
        root.addView(line, lp);
        TextView left = text(name, 18, primary, true);
        line.addView(left, new LinearLayout.LayoutParams(0, -2, 1));
        TextView right = text(hint, 11, muted, false);
        line.addView(right);
    }

    private View card(String label, String value, String detail, int weight) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(15), dp(16), dp(12), dp(16));
        box.setBackground(round(panel, dp(18), edge));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(142), weight);
        lp.rightMargin = dp(8);
        box.setLayoutParams(lp);
        box.addView(text("●  " + label, 12, accent, false));
        TextView val = text(value, 20, primary, true);
        LinearLayout.LayoutParams vlp = new LinearLayout.LayoutParams(-1, -2);
        vlp.topMargin = dp(18);
        box.addView(val, vlp);
        TextView det = text(detail, 11, muted, false);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(-1, -2);
        dlp.topMargin = dp(8);
        box.addView(det, dlp);
        return box;
    }

    private View actionCard(String label, String detail, final Runnable action) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setPadding(dp(14), dp(15), dp(10), dp(15));
        box.setBackground(round(panel, dp(16), edge));
        box.setClickable(true);
        box.setFocusable(true);
        box.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { action.run(); }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(88), 1);
        lp.rightMargin = dp(8);
        box.setLayoutParams(lp);
        box.addView(text(label, 15, primary, true));
        TextView sub = text(detail, 11, muted, false);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-1, -2);
        slp.topMargin = dp(7);
        box.addView(sub, slp);
        return box;
    }

    private void launch(String action) {
        try { startActivity(new Intent(action)); }
        catch (Exception e) { Toast.makeText(this, "此设置页面暂不可打开", Toast.LENGTH_SHORT).show(); }
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setIncludeFontPadding(true);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private android.graphics.drawable.GradientDrawable round(int color, int radius, int stroke) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        d.setStroke(dp(1), stroke);
        return d;
    }

    private int dp(float value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
